from .sementic import embed, match_embeddings

class Nzacha:
    def __init__(self,
                 chunk_size = 200,
                 overlap = 20,
                 openai_api_key: str = None ,
                 threshold = 0.6):
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.openai_api_key =openai_api_key
        self.threshold = threshold

        self.text_chunks = []
        self.embeddings = []

    def add_by_words(self, data: str | list):
        if not isinstance(data, (str, list)):
            raise TypeError("data must be a string or a list")

        if self.overlap >= self.chunk_size:
            raise ValueError("Overlap must be smaller than chunk size")

        if isinstance(data, str):
            data = data.split()

            start = 0
            while start < len(data):
                end = start + self.chunk_size
                chunk = data[start:end]

                chunk_text = " ".join(chunk)

                self.text_chunks.append(chunk_text)

                embedding = embed(chunk_text, self.openai_api_key)
                self.embeddings.append(embedding)

                start += (self.chunk_size - self.overlap)


        else:
            for m in data:
                self.text_chunks.append(str(m))
                embedding = embed(str(m),self.openai_api_key)
                self.embeddings.append(embedding)
        return self.text_chunks

    def search(self, query: str):
        query_embedding = embed(query, self.openai_api_key)

        related = match_embeddings(self.embeddings, query_embedding, self.threshold)

        related_data = []

        for item in related:
            index = item["index"]
            related_data.append(self.text_chunks[index])


        if not related_data:
            return "No strong semantic matches found. Consider lowering threshold."
        else:
            return related_data




